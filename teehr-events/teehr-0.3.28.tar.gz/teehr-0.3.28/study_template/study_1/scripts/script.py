"""A module for study template scripts."""
