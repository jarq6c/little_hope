"""A module for dashboard utils."""
