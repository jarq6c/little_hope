"""TEEHR API init."""
