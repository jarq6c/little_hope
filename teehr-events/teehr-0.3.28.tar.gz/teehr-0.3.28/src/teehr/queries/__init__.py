"""Queries init."""
import duckdb
