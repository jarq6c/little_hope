"""Loading for Nextgen data -- Work In Progress."""
