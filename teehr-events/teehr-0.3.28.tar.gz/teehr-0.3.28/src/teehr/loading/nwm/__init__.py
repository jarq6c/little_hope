"""Functionality for fetching and formatting NWM data."""
