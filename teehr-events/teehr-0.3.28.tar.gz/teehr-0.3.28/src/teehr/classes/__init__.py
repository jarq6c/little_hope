"""TEEHR classes init."""
