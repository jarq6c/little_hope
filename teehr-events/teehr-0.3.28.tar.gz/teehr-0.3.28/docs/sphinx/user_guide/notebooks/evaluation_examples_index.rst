===================
Evaluation Examples
===================


.. toctree::
   :maxdepth: 2

   Ex.1 - Building a Simple TEEHR Dataset </user_guide/notebooks/evaluation/01-ex1-simple>
   Ex.2 - Building a Joined Database </user_guide/notebooks/evaluation/02-ex2_join_data>
   Ex.2 (cont'd) - Evaluating and Visualizing </user_guide/notebooks/evaluation/03-ex2_evaluate>
   Ex.3 - Evaluating and Visualizing </user_guide/notebooks/evaluation/04-ex3_evaluate>