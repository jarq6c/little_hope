# Playground
This is a location to store ideas that are not fully ready for
inclusion the library but may still have value.
