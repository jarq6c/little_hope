// DashboardContext.js
import { createContext } from "react";

const DashboardContext = createContext(null);

export default DashboardContext;
